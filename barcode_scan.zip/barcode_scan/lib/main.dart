import 'package:flutter/material.dart';
import 'package:barcode_scan/barcode_scan.dart';
import 'package:flutter/services.dart';
import 'dart:async';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  // This widget is the root of your application.
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  String result ="hey there";
 Future _scanQR() async{
    try{
     // var result ="hey there";
    var  qrResult =  await BarcodeScanner.scan();
      setState(() {
      result = qrResult as String ;

      });
    }on PlatformException catch(ex){
      if(ex.code == BarcodeScanner.cameraAccessDenied) {
        setState(() {
          result = "camera permission denied";
        });
      }
      else{
        setState(() {
          result= "unknown exception $ex";
        });
      }
    } on FormatException{
      setState(() {
        result="you pressed the back button before scanning";
      });
    }catch(ex){
      setState(() {
        result= "unknown exception $ex";
      });
    }

  }
  Widget build(BuildContext context) {
    return MaterialApp(
     home: Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          label: Text("+",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
          onPressed: (){
            _scanQR;
            },
      ),
       floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      )
      );
   }
}
